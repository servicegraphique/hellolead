// This is a static export: do not submit personal data to a missing WordPress backend.
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('form').forEach(function (form) {
    var message = document.createElement('p');
    message.className = 'local-form-notice';
    message.setAttribute('role', 'status');
    message.textContent = 'Ce formulaire ne peut pas être envoyé depuis cette copie statique. Un service de réception doit être configuré.';
    form.insertAdjacentElement('beforebegin', message);
  });
});
document.addEventListener('submit', function (event) {
  event.preventDefault();
  event.stopImmediatePropagation();
}, true);
